public class BoksVolum {

	public static void main(String[] args) {

		int b, h, d;
		String btext, htext, dtext;

		[ ... ]
		    
		int volum = b * h * d;

		String respons = 
				"Volum [" + htext + "," + btext + "," + dtext + "] = " + volum;

	}
}
