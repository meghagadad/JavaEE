# DAT250: Report for the software technology study project

Latex is a text processing system aimed at scientific writing.  

This repository contains starter LaTeX code that you can use for writing the project report. The example code should have must constructs that you will need to get write the report. Learning LaTeX will also be helpful for later writing you master's thesis report.

LaTeX is available for several platforms (Windows, Mac OS, Linux). A good place to start is here: https://www.latex-project.org/get/

It is certainly possible to use LaTeX is more advanced ways compared to what is shown here. If you have suggestion for extension of the template contact Lars.


