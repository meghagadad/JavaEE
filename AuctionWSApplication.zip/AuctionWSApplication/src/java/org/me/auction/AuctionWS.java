/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.auction;


import entities.AuctionBid;
import entities.AuctionProduct;
import entities.Message;
import entities.ProductFacade;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author sigri
 */
@WebService(serviceName = "AuctionWS")
@Stateless()
public class AuctionWS {
 
    ProductFacade pf = new ProductFacade();
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public int operation(@WebParam(name = "i") int i, @WebParam(name = "j") int j) {
        
        return (i+j);
    }
    
    
    /**
     * Auctions that are still active
     */
    @WebMethod(operationName= "getActiveAuctions")
    public List<AuctionProduct> getActiveAuctions (){
        
        return pf.getAllActiveProducts();
    }
    
    
    /**
     * Bid feedback
     * @param bid
     * @return 
     */
    @WebMethod(operationName= "bidForAuction")
    public Message bidForProduct(@WebParam(name="bid") AuctionBid bid){
    Message message = new Message(200, "A-ok! Bid is a success!");
        if (bid.getProductId() == null)
            message = new Message(404, "Product id invalid");
        if (pf.getCurrentProductPrice(bid.getProductId())<bid.getAmount())
            message = new Message(400, "Bid amount is not enough");
        return message;
    } 
}
