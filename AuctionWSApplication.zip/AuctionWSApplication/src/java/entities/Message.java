/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author sigri
 */
public class Message {
    
    /**
     * The message object you return in the second method should be a message 
     * containing a status code and an explanation string. The message either 
     * return a success message (e.g. “Customer X’s bid has been successfully 
     * placed for product Y”), or an error message (e.g. “The bid for product 
     * Y has not been placed for customer X”) and indicate if an error occurred 
     * by a status code or by the message type.
     */
    
    
    private int statusCode;
    private String explanation;

    public Message(int statusCode, String explenation) {
        this.statusCode=statusCode;
        this.explanation=explanation;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
    
    
    
    
    
}
